{------------------------------------------------------------------------------
 - 
 - BasicData.hs
 -
 - Christopher Salinas
 - Gavin McGuire
 -
 - CS 456
 - Fall 2020
 - University of New Mexico
 -
------------------------------------------------------------------------------}

module BasicData where
  data Expr = Id Char
            | Num { val :: Int }
            | Int' Expr
            | Rnd Expr
            | CompareExpr String Expr Expr
            | MultExpr Char Expr Expr
            | AddExpr Expr Expr
            | NegateExpr Expr
            | PowerExpr Expr Expr

  instance Show Expr where
    show (Id c) =  [c]
    show (Num n) = show n
    show (Int' e) = "INT(" ++ show e ++ ")"
    show (Rnd e) = "RND(" ++ show e ++ ")"
    show (MultExpr c lhs rhs) = show lhs ++ " " ++ [c] ++ " " ++ show rhs
    show (AddExpr lhs rhs) = show lhs ++ " + " ++ show rhs
    show (CompareExpr op lhs rhs) = show lhs++ " " ++ op ++ " " ++ show rhs
    show (NegateExpr e) = "- " ++ show e
    show (PowerExpr base power) = show base ++ " ^ " ++ show power

  data Statement = END 
                 | FOR Expr Expr Expr
                 | LET Expr Expr
                 | NEXT [Expr]
                 | PRINT Expr
                 | IFTHEN Expr Int
                 | INPUT String [Expr]

  instance Show Statement where
    show END = "END"
    show (FOR id init lim) = "FOR " ++ show id ++ " = " ++ show init ++ " TO " ++ show lim
    show (LET lhs rhs) = "LET " ++ show lhs ++ " = " ++ show rhs
    show (NEXT exprs) = "NEXT" ++ showExprList exprs
    show (PRINT e) = "PRINT " ++ show e
    show (IFTHEN e line) = "IF " ++ show e ++ " THEN " ++ show line
    show (INPUT "" exprs) = "INPUT" ++ showExprList exprs
    show (INPUT str exprs) = "INPUT " ++ str ++ ";" ++ showExprList exprs

  showExprList exprs = concat $ fmap addSpace exprs
  addSpace expr = " " ++ show expr
