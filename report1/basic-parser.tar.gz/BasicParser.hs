{-----------------------------------------------------------------------------
 - 
 - BasicParser.hs
 -
 - Christopher Salinas
 - Gavin McGuire
 -
 - CS 456
 - Fall 2020
 - University of New Mexico
 -
 -----------------------------------------------------------------------------}

module BasicParser where
  import BasicData
  import Parselib
  import System.IO

  -- STATEMENT PARSERS
  stmt :: Parser Statement
  stmt = end +++ for' +++ ifthen +++ input +++ let' +++ next' +++ print'

  end :: Parser Statement
  end = do
    symb "END"
    return END

  let' :: Parser Statement
  let' = do
    symb "LET"
    var <- id'
    symb "="
    val <- expr
    return $ LET var val

  print' :: Parser Statement
  print' = do
    symb "PRINT"
    e <- expr
    return $ PRINT e

  input :: Parser Statement
  input = do
    symb "INPUT"
    ids <- many id'
    return $ INPUT [] ids

    
  ifthen :: Parser Statement
  ifthen = do
    symb "IF"
    e <- expr
    symb "THEN"
    n <- nat
    return $ IFTHEN e n

  for' :: Parser Statement
  for' = do
    symb "FOR"
    var <- id'
    symb "="
    val <- expr
    symb "TO"
    e <- expr
    return $ FOR var val e

  next' :: Parser Statement
  next' = do
    symb "NEXT"
    ids <- many id'
    return $ NEXT ids

  -- EXPRESSION PARSERS
  expr :: Parser Expr
  expr = compareExpr

  compareExpr :: Parser Expr
  compareExpr = equate +++ addExpr

  equate :: Parser Expr 
  equate = do
    m <- addExpr
    symb "="
    a <- compareExpr
    return $ CompareExpr "=" m a

  addExpr :: Parser Expr
  addExpr = add +++ multExpr

  add :: Parser Expr
  add = do
    m <- multExpr
    symb "+" +++ symb "-"
    a <- expr
    return $ AddExpr m a

  multExpr :: Parser Expr
  multExpr = multTimes +++ multDiv +++ negateExpr

  multTimes :: Parser Expr
  multTimes = do
    n <- negateExpr
    symb "*"
    m <- expr
    return $ MultExpr '*' n m

  multDiv :: Parser Expr
  multDiv = do
    n <- negateExpr
    symb "/"
    m <- expr
    return $ MultExpr '/' n m

  negateExpr :: Parser Expr
  negateExpr = negate' +++ powerExpr

  negate' :: Parser Expr
  negate' = do
    symb "-"
    p <- expr
    return $ NegateExpr p

  powerExpr :: Parser Expr
  powerExpr = power +++ value

  power :: Parser Expr
  power = do
    v <- value
    symb "^"
    p <- expr
    return $ PowerExpr v p

  value :: Parser Expr
  value = parens +++ function +++ variable +++ constant

  parens :: Parser Expr
  parens = do
    symb "("
    e <- expr
    symb ")"
    return e

  variable :: Parser Expr
  variable = id'

  id' :: Parser Expr
  id' = do
    c <- token letter
    return $ Id c

  function :: Parser Expr
  function = int' +++ rnd

  int' :: Parser Expr
  int' = do
    symb "INT"
    e <- parens
    return $ Int' e
  
  rnd :: Parser Expr
  rnd  = do
    symb "RND"
    e <- parens
    return $ Rnd e

  constant :: Parser Expr
  constant = number

  number :: Parser Expr
  number = do
    n <- nat
    return $ Num n

  -- PARSING FUNCTIONS
  line :: Parser (Int, Statement)
  line = do
    n <- number -- line number
    s <- stmt
    return (val n, s)

  p :: String -> (Int, Statement)
  p s = case apply line s of
    [(a, "")] -> a
    _ -> error "Parser error."

  parse' :: Handle -> IO [(Int, Statement)]
  parse' handle = do
    eof <- hIsEOF handle
    if eof then return []
    else do
      s <- hGetLine handle
      let stmt = p s
      stmts <- parse' handle
      return $ [stmt] ++ stmts